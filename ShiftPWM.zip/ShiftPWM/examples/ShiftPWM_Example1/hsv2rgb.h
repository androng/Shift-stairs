#ifndef RGB2HSV_h
#define RGB2HSV_h

void hsv2rgb(unsigned int hue, unsigned int sat, unsigned int val, \
              unsigned char * r, unsigned char * g, unsigned char * b, unsigned char maxBrightness );

#endif

